import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * �����
 * ������ ��ҵ
 * ��ҳԴ����  �������
 * java��������
 */
public class RegExp {

	/**
	 * @param args
	 */
	/*
	 * java��������  
	 */
	public static void synCountCode(String url){
		File file = new File(url);
		
		FileReader fr;
		try {
			fr = new FileReader(file);
			BufferedReader br=new BufferedReader(fr);
			String line="";
			ArrayList lines = new ArrayList();
			int i=0;
			while((line=br.readLine())!=null){
				lines.add(line);
				i++;
			}
			parse(lines);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void parse(ArrayList lines) {
		
		// TODO Auto-generated method stub
		int codeNumber=0;//��Ч��
		int commentsNumber=0;  //ע����
		int emptyNumber=0;
		Pattern p1=Pattern.compile("^\\s*$");//����
		Pattern p2=Pattern.compile("(?!import|package).+;\\s*(((//)|(/\\*+)).*)*",
					Pattern.MULTILINE + Pattern.DOTALL);//������
		Pattern p3=Pattern.compile("((//)|(/\\*+)|((^\\s)*\\*)|((^\\s)*\\*+/))+", 
				Pattern.MULTILINE + Pattern.DOTALL);//ע����
		for(int i=0;i<lines.size();i++){
			Matcher m=null;
			
			if(p1.matcher((String)lines.get(i)).find() ){
				emptyNumber++;
			}
			else if(p2.matcher((String)lines.get(i)).find()){
				codeNumber++;
			}
			else{
				commentsNumber++;
			}
		}
		
		System.out.println("��Ч���� : "+codeNumber);
		System.out.println("ע������ : "+commentsNumber);
		System.out.println("������ : "+emptyNumber);
		
		
	}
	public static void regsEmail(String url){
		test01_02 res=new test01_02(url);
		char[] ca=res.ReadFile(url);
		 String des=new String(ca);
		 Pattern p=Pattern.compile("[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+");
			Matcher m=p.matcher(des);
			while(m.find()){
				System.out.println(m.group());//matchesֻ��ƥ��һ��
			}
		/* String[] sp=des.split("\n");
		  for(int i=0;i<sp.length;i++){
			  Pattern p=Pattern.compile("[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+");
				Matcher m=p.matcher(sp[i]);
				while(m.find()){
					System.out.println(m.group());//matchesֻ��ƥ��һ��
				}
			  
		  }*/
		 
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ƥ������
		//System.out.println("-@.com".matches("[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+"));
		//String url="E:/����ԭ��/������/email.htm";
		//regsEmail(url);
		String url="E:/����ԭ��/Test01/src/test01_01.java";
		synCountCode(url);
		

	}

}
