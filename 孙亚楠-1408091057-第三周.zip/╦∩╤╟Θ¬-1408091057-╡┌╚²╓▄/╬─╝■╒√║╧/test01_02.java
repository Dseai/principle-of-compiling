import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
/**
 * ��ҵ2
 * @author �����
 * �����ַ�����txt�ļ��� ��ȡ�ĵ�����ӡ������̨
 *
 */

public class test01_02 {

	/**
	 * @param args
	 */
	public String fileUrl;
	public test01_02(String fileUrl){
		this.fileUrl=fileUrl;
	}
	public void ReadFile(String fileUrl){
      File file1=new File(fileUrl);
		
		char[] ca=new char[(int)file1.length()];
		try {
			FileReader fileReader=new FileReader(file1);
			fileReader.read(ca);
			System.out.println(ca);
			fileReader.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	/*
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		File file1=new File("E:/����ԭ��/��һ���ϻ�����/test01.txt");
		
		char[] ca=new char[(int)file1.length()];
		try {
			FileReader fileReader=new FileReader(file1);
			fileReader.read(ca);
			System.out.println(ca);
			fileReader.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}*/

}
