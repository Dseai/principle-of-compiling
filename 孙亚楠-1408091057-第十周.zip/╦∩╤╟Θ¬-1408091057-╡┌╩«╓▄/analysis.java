package pridictTable.src;

import java.util.*;
public class analysis {
	public static void main(String args[]){
		Scanner scanner = new Scanner(System.in);	
		String str = scanner.nextLine();
		HashMap<String, Integer> row_map = new HashMap<String, Integer>(){
			{
				put("S", 0);put("A", 1);put("B", 2);put("C", 3);put("D", 4);put("E", 5);
			}
		};
		HashMap<String, Integer> col_map = new HashMap<String, Integer>(){
			{
				put("a", 0);put("b", 1);put("c", 2);put("d", 3);put("e", 4);put("f", 5);
			}
		};
		String[][] table = {{"aD", "BCD", "BCD", "BCD", "-1", "-1", "-1"},
							{"aA", "-1", "-1", "CEB", "CEB", "CEB", "-1"},
							{"-1", "b", "!", "!", "!", "!", "!"}, 
							{"-1", "-1", "!", "dB", "!", "!", "!"}, 
							{"-1", "-1", "cA", "-1", "-1", "-1", "!"}, 
							{"-1", "-1","-1", "-1", "e", "fE", "-1"}};
		Stack<String> stack = new Stack<String>();
		stack.push("#");
		stack.push("S");
		int row_ind, col_ind;
		int str_point = 0;
		boolean flag = true;
		while (str_point != str.length()) {
			String current_lex = stack.pop();
			if (current_lex.equals("#")) {
				break;			
			}
			String current_str = "" + str.charAt(str_point);
			row_ind = row_map.get(current_lex);
			col_ind = col_map.get(current_str);
			String cur = table[row_ind][col_ind];
			if (cur.equals("-1")){
				break;
			}
			for (int i = cur.length() - 1; i >= 0 ; i--) {
				if ("!".equals(""+cur.charAt(i))) {
					continue;
				}
				stack.push(""+cur.charAt(i));
			}
			if (current_str.equals(stack.peek())){
				str_point++;
				stack.pop();
			}
		}
		if (stack.peek().equals("#") && str_point == str.length())
			System.out.println("����");
		else
			System.out.println("������");
		scanner.close();
	}
}
